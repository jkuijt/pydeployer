# pydeployer

Simple library for deploying local project files to a remote machine
