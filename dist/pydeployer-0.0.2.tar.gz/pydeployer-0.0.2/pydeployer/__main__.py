import logging

logger = logging.getLogger(__name__)

def main():
	print("hello world")
	print(__version__)

if __name__ == '__main__':
	main()